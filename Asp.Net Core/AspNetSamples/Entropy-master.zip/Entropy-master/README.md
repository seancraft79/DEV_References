Entropy
=======
AppVeyor: [![AppVeyor](https://ci.appveyor.com/api/projects/status/0o7es2mlb959nmqh/branch/dev?svg=true)](https://ci.appveyor.com/project/aspnetci/Entropy/branch/dev)

Travis:   [![Travis](https://travis-ci.org/aspnet/Entropy.svg?branch=dev)](https://travis-ci.org/aspnet/Entropy)

Entropy is "a measure of the disorder that exists in a system."

This repo is a chaotic experimental playground for new features and ideas. Check here for small and simple samples for individual features.

This project is part of ASP.NET Core. You can find samples, documentation and getting started instructions for ASP.NET Core at the [Home](https://www.github.com/aspnet/home) repo.

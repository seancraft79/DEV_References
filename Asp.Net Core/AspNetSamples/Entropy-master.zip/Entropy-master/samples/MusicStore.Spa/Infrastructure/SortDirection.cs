﻿using System;

namespace MusicStore.Infrastructure
{
    public enum SortDirection
    {
	    Ascending,
        Descending
    }
}
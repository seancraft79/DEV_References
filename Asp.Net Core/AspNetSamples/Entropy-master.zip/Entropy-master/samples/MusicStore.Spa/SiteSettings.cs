﻿using System;

namespace MusicStore.Spa
{
    public class SiteSettings
    {
        public string DefaultAdminUsername { get; set; }
        public string DefaultAdminPassword { get; set; }
    }
}
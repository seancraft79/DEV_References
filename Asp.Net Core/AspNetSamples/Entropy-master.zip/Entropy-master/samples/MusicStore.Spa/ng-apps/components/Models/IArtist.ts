module MusicStore.Models {
    export interface IArtist {
        ArtistId: number;
        Name: string;
    }
} 
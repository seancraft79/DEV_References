module MusicStore.Models {
    export interface IGenre {
        GenreId: number;
        Name: string;
        Description: string;
    }
} 
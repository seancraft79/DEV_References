module MusicStore.Models {
    export interface IGenreLookup {
        GenreId: number;
        Name: string;
    }
} 
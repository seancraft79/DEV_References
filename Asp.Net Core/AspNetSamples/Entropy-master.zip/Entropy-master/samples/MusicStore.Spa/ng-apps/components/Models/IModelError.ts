﻿module MusicStore.Models {
    export interface IModelError {
        FieldName: string;
        ErrorMessage: string;
    }
}   
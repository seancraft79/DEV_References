Mvc.CustomRazorPageHandlers
===

This application exhibits creating an IPageApplicationModelProvider that allows customizing the naming format for handlers on a Razor Page \ PageModel.

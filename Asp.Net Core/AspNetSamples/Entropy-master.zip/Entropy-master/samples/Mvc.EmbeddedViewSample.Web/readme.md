EmbeddedViewSample.Web
===

This web site illustrates use cases for `RazorViewEngineOptions.FileProvider`.

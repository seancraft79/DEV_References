FormatFilterSample.Web
===

This web site illustrates in depth the process of using new feature URL Media header mappings. It demonstrates adding
URL formats and content type mappings and using them. It also shows how routes need to change for this feature to work.

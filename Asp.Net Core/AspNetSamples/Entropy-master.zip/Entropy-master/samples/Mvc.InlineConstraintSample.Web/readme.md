InlineConstraintSample.Web
===

This web site illustrates how to use inline route constraints with traditional
routes. The startup class in its configure method reads the routes which are added to configuration by the
test methods.

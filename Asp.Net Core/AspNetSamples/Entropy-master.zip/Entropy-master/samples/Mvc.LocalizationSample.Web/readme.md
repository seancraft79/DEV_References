Mvc.LocalizationSample.Web
===

This web site illustrates use cases for MVC localization.

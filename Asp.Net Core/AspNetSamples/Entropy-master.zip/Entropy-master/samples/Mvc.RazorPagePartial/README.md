Mvc.RazorPagePartial
===

This application demonstrates using a model for performing partial updates using Razor Pages

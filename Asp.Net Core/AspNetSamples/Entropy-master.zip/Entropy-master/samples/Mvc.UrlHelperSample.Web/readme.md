UrlHelperSample.Web
===

This web site illustrates how to register a `CustomURLHelper` which can based on configuration, generate content
 urls pointing to local or a CDN server and generate lower case urls.
